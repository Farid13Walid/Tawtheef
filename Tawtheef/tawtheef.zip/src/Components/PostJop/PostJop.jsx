import React from 'react'
import style from './PostJop.module.css'

export default function PostJop() {
  return <> 
       <h1>PostJop</h1>
  </> 
    
}