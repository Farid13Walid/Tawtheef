import React from 'react'
import style from './NotFound.module.css'

export default function NotFound() {
  return <> 
       <h1>NotFound</h1>
  </> 
    
}