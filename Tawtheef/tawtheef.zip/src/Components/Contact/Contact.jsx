import React from 'react'
import style from './Contact.module.css'

export default function Contact() {
  return <> 
       <h1>Contact</h1>
  </> 
    
}