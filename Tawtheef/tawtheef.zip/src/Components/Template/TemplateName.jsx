import React from 'react'
import style from './TemplateName.module.css'

export default function TemplateName() {
  return <> 
       <h1>TemplateName</h1>
  </> 
    
}