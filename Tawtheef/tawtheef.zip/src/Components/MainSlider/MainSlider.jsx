import React from 'react'
import style from './MainSlider.module.css'

export default function MainSlider() {
  return <> 
       <h1>MainSlider</h1>
  </> 
    
}